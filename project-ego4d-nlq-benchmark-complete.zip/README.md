
# Project Ego4D NLQ Benchmark

Questo progetto contiene il codice necessario per eseguire il benchmark NLQ di Ego4D.

## Struttura del progetto

- `imports.py`: Contiene tutte le importazioni necessarie.
- `functions.py`: Contiene tutte le definizioni di funzione.
- `main.py`: Script principale per eseguire il codice.

## Istruzioni

1. Clona il repository:
    ```bash
    git clone https://github.com/tuo-username/project-ego4d-nlq-benchmark.git
    cd project-ego4d-nlq-benchmark
    ```

2. Installa le dipendenze:
    ```bash
    pip install -r requirements.txt
    ```

3. Esegui lo script principale:
    ```bash
    python main.py
    ```

## Note

- Assicurati di avere configurato correttamente le credenziali di autenticazione per Google Drive e AWS.
- Modifica i percorsi dei file e altre configurazioni secondo le tue necessità.
